def thing():
    print "BLAHHHHH!"
    print "This is from the test package function."
    print "This too.\n"
