# Really intense and super advanced function used for addition
def Addition(x, y):
    return round((x + .0) + (y + .0), 2)

# Function to subtract y from x
def Subtraction(x, y):
    return round(x - y, 2)

# Divides x by y
def Division(x, y):
    return round((x + .0) / (y + .0), 2)

# Lamb Duh used for mulitplication
Multiplication = lambda x, y: round(x * y, 2)

# Lamb Duh used for moarrr powerrrr
Power = lambda x, y: round(x ** y, 2)